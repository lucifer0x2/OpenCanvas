// Explicit real-DB suite: PG_URL is required; do not silently report a skipped pass.
#[path = "contract/atomic.rs"]
mod atomic;
#[path = "../src/batch.rs"]
mod batch;
#[path = "../src/batch_write.rs"]
mod batch_write;
#[path = "../src/blobs.rs"]
mod blobs;
#[path = "contract/bulk_failure.rs"]
mod bulk_failure;
#[path = "contract/bulk_nodes.rs"]
mod bulk_nodes;
#[path = "contract/bulk_replay.rs"]
mod bulk_replay;
#[path = "../src/compatibility.rs"]
mod compatibility;
#[path = "../src/db.rs"]
mod db;
#[path = "../src/durable_http.rs"]
mod durable_http;
#[path = "../src/events.rs"]
mod events;
#[path = "contract/fast_paths.rs"]
mod fast_paths;
#[path = "../src/http.rs"]
mod http;
#[path = "../src/jobs.rs"]
mod jobs;
#[path = "../src/leases.rs"]
mod leases;
#[path = "contract/notifications.rs"]
mod notifications;
#[path = "../src/profile.rs"]
mod profile;
#[path = "contract/reads.rs"]
mod reads;
#[path = "../src/staging.rs"]
mod staging;
#[path = "contract/support.rs"]
mod support;
#[path = "../src/transport.rs"]
mod transport;

pub struct App {
    url: String,
    wake: tokio::sync::Notify,
}
